import os, json, time, requests, signal, sys
from mfrc522 import SimpleMFRC522
import RPi.GPIO as GPIO
from RPLCD.i2c import CharLCD

LED_RED = int(os.getenv("LED_RED", 17))
LED_BLUE = int(os.getenv("LED_BLUE", 27))
BUZZER_PIN = int(os.getenv("BUZZER_PIN", 18))
RC522_RST = int(os.getenv("RC522_RST", 25))
API = os.getenv("API_BASE_URL", "http://api:8000")
LCD_ADDR = int(os.getenv("LCD_I2C_ADDRESS", "0x27"), 16)
LCD_COLS = int(os.getenv("LCD_COLS", 16))
LCD_ROWS = int(os.getenv("LCD_ROWS", 2))
IDLE_TEXT = os.getenv("LCD_IDLE_TEXT", "Tap card ID")
OK_TEXT = os.getenv("LCD_SUCCESS_TEXT", "Updated successfully")

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
for pin in (LED_RED, LED_BLUE, BUZZER_PIN):
    GPIO.setup(pin, GPIO.OUT)
GPIO.output(LED_RED, GPIO.HIGH)
GPIO.output(LED_BLUE, GPIO.LOW)

lcd = CharLCD(i2c_expander='PCF8574', address=LCD_ADDR, port=1, cols=LCD_COLS, rows=LCD_ROWS)
def lcd_msg(line1="", line2=""):
    lcd.clear()
    lcd.write_string((line1 or "")[:LCD_COLS])
    if LCD_ROWS > 1:
        lcd.crlf()
        lcd.write_string((line2 or "")[:LCD_COLS])

reader = SimpleMFRC522()

with open("/app/drivers.json") as f:
    MAP = json.load(f)

def beep(dur=0.08):
    GPIO.output(BUZZER_PIN, GPIO.HIGH)
    time.sleep(dur)
    GPIO.output(BUZZER_PIN, GPIO.LOW)

def cleanup(*_):
    try:
        lcd.clear()
    except Exception:
        pass
    GPIO.output(LED_RED, GPIO.LOW)
    GPIO.output(LED_BLUE, GPIO.LOW)
    GPIO.cleanup()
    sys.exit(0)

signal.signal(signal.SIGINT, cleanup)
signal.signal(signal.SIGTERM, cleanup)

lcd_msg(IDLE_TEXT)
print("RFID reader running. Tap a card...")
while True:
    try:
        uid, _ = reader.read()
        uid_hex = format(uid, 'x')
        print(f"Card read: {uid_hex}")

        rec = MAP.get(uid_hex) or {"driver_id": f"DRV-{uid_hex}", "bus_id": "BUS-A"}

        GPIO.output(LED_RED, GPIO.LOW)
        GPIO.output(LED_BLUE, GPIO.HIGH)
        beep()

        lcd_msg(OK_TEXT)

        payload = {"driver_id": rec["driver_id"], "bus_id": rec["bus_id"], "status": "leaving"}
        try:
            r = requests.post(f"{API}/events", json=payload, timeout=2.5)
            print("Posted:", r.status_code, r.text[:120])
        except Exception as e:
            print("Post failed:", e)

        time.sleep(2.0)
        lcd_msg(IDLE_TEXT)
        time.sleep(0.5)
    except Exception as e:
        print("Loop error:", e)
        time.sleep(0.5)
